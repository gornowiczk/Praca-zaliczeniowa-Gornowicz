# Smartphone - Portrait and Landscape View

This is a sample project showcasing how to display content on a smartphone in portrait and landscape views. The project utilizes Webpack technology for building and managing assets.

## Requirements

To run this project locally, make sure you have the following software installed:

- Node.js (latest version recommended)

## Installation

1. Clone the repository or download the source code.
2. Navigate to the project's root directory.
3. Run the command `npm install` or `yarn install` to install project dependencies.

## Usage

Once the dependencies are installed, you can build the project by running the command `npm run build` or `yarn build`.
- This command will compile the source files and generate the output file `bundle.js` in the `dist` directory.
- Open the `index.html` file in a browser to see the project in action.

## Project Structure

- `index.html`: The main HTML file that displays the application content.
- `styles.css`: The CSS file containing the application styles.
- `src/`: Directory containing the application source files.
  - `index.js`: The JavaScript file that imports the CSS file and contains the application logic.
- `dist/`: The output directory where the compiled `bundle.js` file is generated.

## Development

If you want to make changes to the project, you can edit the source files in the `src/` directory. Then, after making the changes, rebuild the project to update the output file.

You can also customize the Webpack configuration by editing the `webpack.config.js` file. In the configuration file, you can add additional modules, plugins, and customize other settings as per your project requirements.

## Author

This project was created by Krystian Górnowicz.
