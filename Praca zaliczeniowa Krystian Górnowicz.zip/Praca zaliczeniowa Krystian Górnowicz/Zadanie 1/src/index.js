import './styles.css';

document.addEventListener('DOMContentLoaded', () => {

    function changeText() {
        const heading = document.querySelector('h1');
        heading.textContent = 'Hello, World!';
    }

    changeText();
});
